"""Validate the selected game path and locate its Steam metadata and existing FModel exports."""
import ctypes
import json
import os
import re
from pathlib import Path, PureWindowsPath


_STEAM_APP = "2406770"
_STEAM_MANIFEST = f"appmanifest_{_STEAM_APP}.acf"
_VDF_TOKEN = re.compile(r'\s+|//[^\r\n]*|"(?:\\.|[^"\\])*"|[{}]|[^\s{}"]+')


def _path_local(raw):
    if not raw:
        return None
    try:
        text = os.path.expandvars(os.fspath(raw)).strip().strip('"')
        if not text or "\0" in text:
            return None
        # A UNC is a remote path even when it appears in a local Steam manifest.
        windows_path = PureWindowsPath(text)
        if windows_path.drive.startswith("\\\\") or text.startswith(("//", "\\\\")):
            return None
        path = Path(text).expanduser()
        if os.name == "nt":
            if windows_path.drive and not windows_path.is_absolute():
                return None
            absolute = path.absolute()
            # Mapped network drives would perform remote I/O in is_dir/is_file.
            if ctypes.windll.kernel32.GetDriveTypeW(str(absolute.anchor)) == 4:
                return None
        return path
    except (ValueError, OSError, RuntimeError):
        return None


def _probe_dir(raw):
    path = _path_local(raw)
    try:
        if path is not None and path.is_dir():
            return path.resolve()
    except (ValueError, OSError, RuntimeError):
        pass
    return None


def _read_metadata(path):
    """Steam and FModel metadata are small. Bound read size before decoding."""
    if _path_local(path) is None:
        raise ValueError("Ожидался локальный путь")
    with path.open("rb") as handle:
        data = handle.read(4 * 1024 * 1024 + 1)
    if len(data) > 4 * 1024 * 1024:
        raise ValueError("Слишком большой файл метаданных")
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    if b"\0" in data[:80]:
        return data.decode("utf-16-be" if data.startswith(b"\0") else "utf-16-le")
    return data.decode("utf-8-sig")


def _vdf_file(path):
    """Read nested Valve KeyValues with quoted paths, arrays and // comments."""
    try:
        data = _read_metadata(path)
        result = {}
        stack = [result]
        key = None
        end = 0
        for match in _VDF_TOKEN.finditer(data):
            if match.start() != end:
                return {}
            end = match.end()
            token = match.group()
            if token.isspace() or token.startswith("//"):
                continue
            if token == "{":
                if key is None or len(stack) > 64:
                    return {}
                child = {}
                stack[-1][key] = child
                stack.append(child)
                key = None
            elif token == "}":
                if key is not None or len(stack) == 1:
                    return {}
                stack.pop()
            else:
                if token.startswith('"'):
                    token = re.sub(r'\\(["\\])', r'\1', token[1:-1])
                if key is None:
                    key = token.casefold()
                    if key in stack[-1]:
                        return {}
                else:
                    stack[-1][key] = token
                    key = None
        return result if end == len(data) and len(stack) == 1 and key is None else {}
    except (ValueError, OSError):
        return {}


def _appstate(steamapps):
    state = _vdf_file(steamapps / _STEAM_MANIFEST).get("appstate", {})
    if not isinstance(state, dict) or state.get("appid") != _STEAM_APP:
        return {}
    # Steam's installdir is a single directory under steamapps/common.
    name = state.get("installdir")
    if not isinstance(name, str) or not name.strip() or name in {".", ".."}:
        return {}
    if name != PureWindowsPath(name).name or any(char in name for char in "/\\:"):
        return {}
    return state


def build_id(root: Path) -> str | None:
    root = _probe_dir(root)
    if root is None:
        return None
    common = root.parent
    if common.name.casefold() != "common" or common.parent.name.casefold() != "steamapps":
        return None
    state = _appstate(common.parent)
    if state.get("installdir", "").casefold() != root.name.casefold():
        return None
    build = state.get("buildid")
    return build if isinstance(build, str) and re.fullmatch("[0-9]+", build) else None


def game_root(choice: str) -> Path | None:
    """Accept the selected installation, its executable, or its nested Content/Paks folder."""
    try:
        selected = Path(os.path.expandvars(choice.strip().strip('"'))).expanduser().resolve()
        if selected.is_file() and selected.name.casefold() == "bodycam.exe":
            selected = selected.parent
        if not selected.is_dir():
            return None
        for candidate in (selected, *list(selected.parents)[:3]):
            paks = candidate / "Bodycam" / "Content" / "Paks"
            if selected in (candidate, paks, paks.parent, paks.parent.parent) and paks.is_dir():
                return candidate
    except (OSError, ValueError, RuntimeError):
        pass
    return None


def _fmodel_configured(folder):
    # Settings are optional. Only documented-purpose output paths are considered:
    # game-directory selectors and arbitrary strings in the settings are never enumerated.
    for name in ("AppSettings.json", "Settings.json", "settings.json"):
        try:
            data = json.loads(_read_metadata(folder / name))
        except (ValueError, OSError):
            continue
        if not isinstance(data, dict):
            continue
        for key, raw in data.items():
            if not isinstance(raw, str):
                continue
            key = key.casefold()
            if key not in ("outputdirectory", "propertiesdirectory", "propertydirectory",
                           "exportdirectory", "exportsdirectory"):
                continue
            output = _path_local(raw)
            if output is None or not output.is_absolute():
                continue
            if key == "outputdirectory":
                yield output / "Exports"
            else:
                yield output


def export_roots(overrides: list[str] | None = None) -> list[Path]:
    """Use an explicit list as the entire scope, otherwise probe a bounded list of locations."""
    choices = list(overrides or [])
    if not choices:
        cwd = Path.cwd()
        script = Path(__file__).absolute().parent
        home = Path.home()
        fmodel_dirs = [cwd / "FModel", script / "FModel"]
        # A portable FModel may be unpacked next to the tool or into its current directory.
        for anchor in (cwd, script):
            if anchor.name.casefold() == "fmodel" or (anchor / "FModel.exe").is_file():
                fmodel_dirs.append(anchor)
            choices.append(anchor / "Output" / "Exports")
        fmodel_dirs.extend(home / name / "FModel" for name in ("Documents", "Downloads", "Desktop"))
        fmodel_dirs.append(home / "FModel")
        for name in ("LOCALAPPDATA", "APPDATA", "ProgramFiles", "ProgramFiles(x86)", "OneDrive"):
            base = _path_local(os.environ.get(name))
            if base:
                fmodel_dirs.append(base / "FModel")
                if name == "OneDrive":
                    fmodel_dirs.extend((base / "Documents" / "FModel", base / "Desktop" / "FModel"))
        if os.name == "nt":
            fmodel_dirs.extend((Path(r"D:\FModel"), Path(r"C:\FModel")))
        for folder in dict.fromkeys(fmodel_dirs):
            choices.extend((folder / "Output" / "Exports", folder / "Exports"))
            choices.extend(_fmodel_configured(folder))
    found = []
    for choice in choices:
        root = _probe_dir(choice)
        if root is None or root == root.parent or root == Path.home() or root in found:
            continue
        found.append(root)
    # If overlapping exports were supplied, reading the outer folder once is sufficient.
    return [root for root in found if not any(parent in found for parent in root.parents)]
