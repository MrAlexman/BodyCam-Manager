"""Доказательства из уже разобранных игровых ресурсов. Все адреса — JSON Pointer исходного файла."""
import re


def _field(key):
    # Blueprint fields may carry a property index and a persistent GUID.
    key = re.sub(r"_\d+_[0-9a-fA-F]{32}$", "", str(key))
    return re.sub(r"[^a-z0-9]", "", key.casefold())


def _pointer(parts):
    return "".join("/" + str(key).replace("~", "~0").replace("/", "~1") for key in parts)


def _children(obj, path):
    if isinstance(obj, dict):
        for key, val in obj.items():
            yield key, val, (*path, key)
    elif isinstance(obj, list):
        for i, val in enumerate(obj):
            yield i, val, (*path, i)


def _walk(obj, path=()):
    yield obj, path
    for _, child, subpath in _children(obj, path):
        yield from _walk(child, subpath)


def _named(obj, keys, path=()):
    for key, child, subpath in _children(obj, path):
        if _field(key) in keys:
            yield child, subpath
        else:
            yield from _named(child, keys, subpath)


def _compact(obj, key=""):
    # Binary payloads and sampled motion curves are not evidence of an ADS duration.
    if isinstance(obj, list):
        if _field(key) in {"floatcurves", "compressedbytearray", "rawdata", "keys", "curves"} and len(obj) > 32:
            return {"omitted_array_length": len(obj)}
        if _field(key) == "floatcurves" and any(isinstance(v, list) and len(v) > 32 for v in obj):
            return {"channel_lengths": [len(v) if isinstance(v, list) else None for v in obj]}
        return [_compact(v) for v in obj]
    if isinstance(obj, dict):
        return {k: _compact(v, k) for k, v in obj.items()}
    return obj


def _entry(path, value, role):
    return {"path": _pointer(path), "value": _compact(value, path[-1] if path else ""), "role": role}


def _kind(name):
    basename = name.replace("\\", "/").split("/")[-1].split(".")[0].casefold()
    if basename == "dt_weaponitems":
        return "weapon_items"
    if basename == "dt_commonitems":
        return "common_items"
    if basename in {"dt_weaponskins", "dt_newshopitem", "dt_shopitem", "dt_wep", "dt_primarywep",
                    "dt_secondarywep", "dt_gungameweplist", "dt_gungameweaponlist"}:
        return "item_catalog"
    if basename == "dt_uistatmodifiersdefinition":
        return "stat_definitions"
    if basename == "dt_basicbundles":
        return "bundles"
    if basename == "dt_itemclassesgameplaytags" or basename.startswith(("st_ui_items", "st_ui_weapons")):
        return "display"
    if basename.startswith(("bas_", "additive_")) or "aimin" in _field(basename):
        return "animation"
    if basename.startswith(("ge_", "default__ge_")):
        return "gameplay_effect"
    return "other"


def _row_list(container, path):
    if isinstance(container, dict):
        for key, value, subpath in _children(container, path):
            yield str(key), value, subpath
    elif isinstance(container, list):
        for index, item, subpath in _children(container, path):
            if isinstance(item, dict):
                keys = {_field(k): k for k in item}
                if "key" in keys and "value" in keys:
                    k, v = keys["key"], keys["value"]
                    yield item[k], item[v], (*subpath, v)
                    continue
                name = next((item[keys[k]] for k in ("rowname", "row", "name") if k in keys), None)
                yield name, item, subpath
            else:
                yield None, item, subpath


def _table_rows(data):
    groups = list(_named(data, {"rows", "rowmap"}))
    if groups:
        return [row for group, path in groups for row in _row_list(group, path)]
    if isinstance(data, dict):
        keys = {_field(k) for k in data}
        if "row" in keys or "rowname" in keys:
            row = next((v for k, v in data.items() if _field(k) in {"row", "rowname"}), None)
            return [(row, data, ())]
        if not (keys & {"type", "properties", "class", "exports", "name", "stringtable", "entries", "keystoentries"}) and data and all(
                isinstance(value, (dict, list)) for value in data.values()):
            return list(_row_list(data, ()))
    if isinstance(data, list) and all(isinstance(row, dict) and any(
            _field(k) in {"row", "rowname"} for k in row) for row in data):
        return list(_row_list(data, ()))
    return []


def _ads_token(value):
    normalized = _field(value)
    return (normalized in {"ads", "aimin"} or bool(re.search(r"(?<![a-z0-9])ADS(?![a-z0-9])", str(value), re.I)) or any(t in normalized for t in
            ("adsspeed", "adsblend", "adstime", "adsduration", "sprintads", "aimdownsight", "aimingspeed")))


def _item_role(key):
    if key in {"classid", "itemclassid", "itemclass", "itemid", "itemtag", "tagname", "gameplaytag",
               "itemtype", "itemcategory", "slot", "slottype", "category", "rowname", "row"}:
        return "identity"
    if any(t in key for t in ("displayname", "friendlyname", "itemname", "localizedname", "displaylabel")) or key in {
            "name", "label", "title", "itemtitle", "itemlabel", "titletext", "displaytext", "marketname"}:
        return "display"
    if key in {"itemdefid", "itemdefinitionid", "steamitemid", "marketid", "skinid", "id", "key"}:
        return "identity"
    if any(t in key for t in ("marketclass", "itemhandle", "itemrow", "skinitem", "associateditem",
                               "baseweapon", "baseitem", "itemreference", "weaponclass", "parentitem")):
        return "composition"
    if key in {"animationdata", "animset", "animationset", "weaponanimationdata"}:
        return "animation"
    if any(t in key for t in ("effect", "modifier", "attributemod", "statmod")):
        return "effect"
    if any(t in key for t in ("attachment", "compatible", "requiredmount", "itemcomponent",
                               "defaultpart", "stockpart", "defaultitem", "itemdefinition", "bundle")):
        return "composition"
    return None


def _asset_reference(value):
    if not isinstance(value, str) or len(value) > 2048:
        return False
    return bool(re.search(r"(?:^|['\"])(?:/?(?:Game|Engine|Bodycam(?:/[Cc]ontent|/[Pp]lugins|AnimationFramework)?)/"
                          r"|/[A-Za-z][A-Za-z0-9_]*/|(?:GE_|BAS_)[\w-]+\.)", value, re.I))


def _reference_role(value, path, role):
    if re.search(r"(?:^|[/.'])(?:Default__)?GE_", value, re.I):
        return "effect"
    if re.search(r"(?:^|[/.'])BAS_", value, re.I):
        return "animation"
    if role:
        return role
    if path and _field(path[-1]) in {"objectpath", "assetpathname", "assetpath", "packagename"}:
        return "asset"
    return None


def _visual_field(key):
    return any(word in _field(key) for word in ("texture", "mesh", "material", "thumbnail", "particle",
                                                "previewimage", "objecticon", "skeletal", "rendersetup",
                                                "paintcolor", "skinpattern", "icon", "brush", "tintcolor"))


def _item_evidence(row_name, row, path, catalog_row=False):
    record = {"row": row_name, "path": _pointer(path), "item_kind": "unclassified", "fields": []}
    identities = []
    def visit(obj, p):
        for key, val, q in _children(obj, p):
            if catalog_row and _visual_field(key):
                continue
            role = _item_role(_field(key))
            if role:
                if _field(key) in {"classid", "itemclass", "itemclassid", "itemcategory", "itemtype"}:
                    identities.extend(v for v, _ in _walk(val) if isinstance(v, str))
                # A materialized anim_set may contain megabytes of unrelated animation data.
                if role == "animation" and isinstance(val, dict) and len(val) > 12:
                    record["fields"].append({"path": _pointer(q), "role": "inline_animation"})
                else:
                    record["fields"].append(_entry(q, val, role))
            elif isinstance(val, (dict, list)):
                visit(val, q)
            elif catalog_row and isinstance(val, (str, int)) and not isinstance(val, bool):
                # Keep game-specific row keys and market aliases when a table uses unknown labels.
                record["fields"].append(_entry(q, val, "source_field"))
    visit(row, path)
    is_attachment = any(re.search(r"(?:^|\.)Attachment(?:\.|$)", v, re.I) for v in identities)
    is_weapon = any(re.search(r"(?:^|\.)(?:PrimaryWeapon|SecondaryWeapon|Weapon)(?:\.|$)", v, re.I)
                    for v in identities)
    if is_attachment != is_weapon:
        record["item_kind"] = "attachment" if is_attachment else "weapon"
    return record


def _ads_fields(obj, path, dest, context=""):
    for key, val, q in _children(obj, path):
        norm = _field(key)
        group = context
        if norm in {"adssettings", "adsblend"}:
            group = "ads_settings"
        elif norm in {"aimin", "aiminanimation", "aiminmotion", "aiminmontage"}:
            group = "aim_in"
        elif not group and _ads_token(norm):
            group = "ads_field"
        if group and norm in {"curves", "floatcurves", "keys", "compressedbytearray", "rawdata"}:
            count = len(val) if isinstance(val, (dict, list)) else None
            dest.append({"path": _pointer(q), "role": "curve_samples", "element_count": count})
        elif isinstance(val, (list, dict)):
            if group and not val:
                dest.append(_entry(q, val, group))
            else:
                _ads_fields(val, q, dest, group)
        elif group:
            dest.append(_entry(q, val, group))


def _modifiers(data):
    records = []
    for obj, path in _walk(data):
        if not isinstance(obj, dict):
            continue
        keys = {_field(k): k for k in obj}
        if not (keys.keys() & {"modifierop", "modifiermagnitude", "magnitude", "modop", "operation", "op"}):
            continue
        attrs = [obj[keys[k]] for k in ("attribute", "attributename", "gameplayattribute", "stat", "statid",
                                         "statname", "property", "propertyname", "attr") if k in keys]
        # A GE magnitude can itself contain an 'AttributeBased' calculation. Do not confuse
        # a captured attribute with the target of the modifier that contains this calculation.
        is_mod_entry = bool(attrs) or bool(keys.keys() & {"modifierop", "modop", "modifiermagnitude"})
        if not is_mod_entry:
            continue
        matched = any(_ads_token(v) for attr in attrs for v, _ in _walk(attr) if isinstance(v, str))
        depends = any(_ads_token(v) for v, _ in _walk(obj) if isinstance(v, str))
        if matched or depends or not attrs:
            kind = "ads_target" if matched else ("ads_dependency_or_condition" if depends else "unresolved_target")
            records.append(_entry(path, obj, kind))
    return records


def collect_asset(name: str, data: object) -> dict:
    """Retain addressed evidence only. No field gets an inferred unit or an inferred link."""
    kind = _kind(name)
    if kind == "other":
        top = data
        if isinstance(data, dict):
            top = data.get("exports", data.get("Exports", data))
        for export in top if isinstance(top, list) else [top]:
            if isinstance(export, dict):
                label = next((v for k, v in export.items() if _field(k) in {"name", "objectname"}
                              and isinstance(v, str)), "")
                detected = _kind(label)
                if detected != "other":
                    kind = detected
                    break
        if isinstance(data, dict) and {"anim_set", "row"}.issubset(data):
            kind = "weapon_items"
    result = dict(asset=name, kind=kind, items=[], bundles=[], display_names=[], ads_fields=[],
                  modifiers=[], effect_context=[], references=[], notes=[])
    rows = _table_rows(data) if kind in {"weapon_items", "common_items", "item_catalog", "bundles", "display", "stat_definitions"} else []
    if kind in {"weapon_items", "common_items", "item_catalog"}:
        result["items"] = [_item_evidence(row_name, row, path, kind == "item_catalog") for row_name, row, path in rows]
    elif kind == "stat_definitions":
        for row_name, row, path in rows:
            if _ads_token(row_name) or any(_ads_token(val) for val, _ in _walk(row) if isinstance(val, str)):
                result["ads_fields"].append(_entry(path, row, "stat_definition"))
    elif kind == "bundles":
        # No dependency on a particular field name for bundles. Empty slots, row handles
        # and overrides must all survive even in a previously unseen bundle schema.
        result["bundles"] = [dict(row=row_name, path=_pointer(path), value=_compact(row))
                             for row_name, row, path in rows]
    elif kind == "display":
        tables = list(_named(data, {"keystoentries", "keysstrings", "keystosourcestring", "keystosourcestrings", "entries", "strings", "sourcelocalizedstrings"}))
        result["display_names"] = [dict(row=row_name, path=_pointer(path), value=_compact(row))
                                   for row_name, row, path in rows]
        for table, path in tables:
            result["display_names"].extend(dict(row=k, path=_pointer(p), value=_compact(v))
                                           for k, v, p in _row_list(table, path))
        if not rows and not tables:
            # Some CUE4Parse versions serialize string-table keys directly under StringTable.
            for table, path in _named(data, {"stringtable", "stringtabledata"}):
                result["display_names"].append(_entry(path, table, "raw_string_table"))
    if kind in {"weapon_items", "common_items", "item_catalog", "bundles"} and not rows:
        result["notes"].append("Структура таблицы строк не распознана или таблица пуста.")
    _ads_fields(data, (), result["ads_fields"])
    result["modifiers"] = _modifiers(data)
    if kind == "gameplay_effect":
        context = {"durationpolicy", "durationmagnitude", "period", "stackingtype", "stacklimitcount",
                   "applicationtagrequirements", "ongoingtagrequirements", "targettagrequirements",
                   "sourcetagrequirements", "executions", "components", "gecomponents",
                   "applicationrequirements", "grantedapplicationimmunitytags"}
        for val, path in _named(data, context):
            result["effect_context"].append(_entry(path, val, "effect_context"))
        if not result["modifiers"]:
            result["notes"].append("В выгруженных полях этого эффекта модификатор ADS не обнаружен.")
    # Collect every referenced GE or BAS, even when the owner uses a new field name.
    for value, path in _walk(data):
        if not _asset_reference(value) or (kind == "item_catalog" and any(_visual_field(k) for k in path)):
            continue
        roles = [_item_role(_field(step)) for step in path]
        role = next((r for r in reversed(roles) if r), None)
        if role == "animation":
            owner = max(i for i, field in enumerate(roles) if field == role)
            # A fully materialized anim_set may contain recoil, sound and locomotion assets.
            # Only a direct reference documents the row→animation-set relation.
            if any(isinstance(k, str) and _field(k) not in {"path", "value", "objectpath", "objectname",
                   "assetpathname", "assetpath", "assetname", "packagename", "reference", "ref"}
                   for k in path[owner + 1:]):
                role = None
        if any(_field(step).startswith("aimin") for step in path):
            role = "aim_in"
        role = _reference_role(value, path, role)
        if role:
            result["references"].append(_entry(path, value, role))
    return result
