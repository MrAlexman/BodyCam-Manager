"""Собирает данные ADS из выбранной установки Bodycam в один переносимый JSON."""
import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile
import zlib

from ads_fields import collect_asset
from ads_paths import build_id, export_roots, game_root
from ads_repak import PakError, PakReader
from ads_targets import normalize_asset_path, target_kind

BASE = Path(__file__).resolve().parent
MAX_PART = 64 * 1024 * 1024
TABLE = "/game/bodycamcore/itemsdefinition/gameplay/dt_weaponitems"


def progress(message):
    print(message, flush=True)


def save_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".bodycam-", suffix=".tmp",
                                     mode="w", encoding="utf-8", delete=False) as stream:
        tmp = Path(stream.name)
    try:
        with tmp.open("w", encoding="utf-8") as stream:
            json.dump(obj, stream, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            stream.write("\n")
        # Reserve a name before replacing it, so concurrent runs preserve both reports.
        for number in range(10000):
            result = path if not number else path.with_name(f"{path.stem}_{number + 1}{path.suffix}")
            try:
                with result.open("xb"):
                    pass
            except FileExistsError:
                continue
            try:
                os.replace(tmp, result)
            except OSError:
                result.unlink(missing_ok=True)
                raise
            return result
        raise OSError("Не удалось выбрать свободное имя JSON.")
    finally:
        tmp.unlink(missing_ok=True)


def blob(report, data):
    digest = hashlib.sha256(data).hexdigest()
    if digest not in report["blobs"]:
        report["blobs"][digest] = {
            "bytes": len(data),
            "zlib_base64": base64.b64encode(zlib.compress(data, 9)).decode("ascii"),
        }
    return digest


def resource(report, path, kind):
    virtual = normalize_asset_path(path)
    return report["packages"].setdefault(virtual.casefold(), {
        "package": virtual, "kind": kind, "in_manifest": False, "variants": [],
    })


def read_manifest(root, report):
    manifest = root / "Manifest_UFSFiles_Win64.txt"
    if not manifest.is_file():
        return {"status": "not_found"}
    with manifest.open("rb") as source:
        prefix = source.read(4)
    if prefix.startswith((b"\xff\xfe", b"\xfe\xff")):
        encoding = "utf-16"
    else:
        encoding = "utf-8-sig"
    count = 0
    with manifest.open(encoding=encoding, errors="replace") as source:
        for line in source:
            path = line.rstrip("\r\n").split("\t", 1)[0]
            if not path.lower().endswith(".uasset"):
                continue
            kind = target_kind(path)
            if kind:
                resource(report, path, kind)["in_manifest"] = True
                count += 1
    return {"status": "read", "matched_packages": count}


def file_groups(paths):
    groups = {}
    for path in paths:
        suffix = Path(path).suffix.casefold()
        if suffix not in {".uasset", ".uexp"}:
            continue
        kind = target_kind(path)
        if kind:
            key = path.replace("\\", "/").rsplit(".", 1)[0]
            group = groups.setdefault(key, (path, kind, {}))
            group[2][suffix] = path
    return groups


def scan_archives(root, report, tmp, staged):
    files = sorted((root / "Bodycam" / "Content" / "Paks").glob("*.pak"),
                   key=lambda f: f.name.casefold())
    archive_rows = report["archives"]
    with PakReader() as reader:
        for n, pak in enumerate(files, 1):
            progress(f"[{n}/{len(files)}] {pak.name}")
            entry = {"name": pak.name}
            archive_rows.append(entry)
            try:
                paths = reader.list(pak)
            except (PakError, OSError) as exc:
                entry["index_status"] = getattr(exc, "code", "io_error")
                continue
            groups = file_groups(paths)
            entry.update(index_status="listed", files_listed=len(paths), matching_packages=len(groups))
            for path, kind, parts in groups.values():
                package = resource(report, path, kind)
                # Keep different copies separate. Patch ordering and sidecar provenance matter.
                variant = {"archive": pak.name, "parts": {}}
                package["variants"].append(variant)
                leaf = normalize_asset_path(path).rsplit("/", 1)[-1]
                safe_leaf = re.sub(r'[^\w .-]', "_", leaf)[:110].strip(" .") or "asset"
                # Sequence is assigned for every candidate, including incomplete pairs.
                rel = Path(f"{len(staged):06d}") / safe_leaf
                header = rel.parent / (rel.name + ".uasset")
                staged[header.as_posix()] = variant
                for suffix, member in parts.items():
                    info = {"path": member}
                    variant["parts"][suffix] = info
                    try:
                        data = reader.get(pak, member, max_bytes=MAX_PART)
                    except (PakError, OSError) as exc:
                        info["status"] = getattr(exc, "code", "io_error")
                        continue
                    info.update(status="read", sha256=blob(report, data), bytes=len(data))
                    dest = tmp / rel.parent / (rel.name + suffix)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(data)


def load_properties(data):
    def parse_number(token):
        value = float(token)
        return value if math.isfinite(value) else token
    return json.loads(data, parse_constant=str, parse_float=parse_number)


def evidence(name, decoded):
    return {k: v for k, v in collect_asset(name, decoded).items() if v or k == "kind"}


def decode_local(tmp, stage_map, report, mapping):
    from ads_decode import decode_packages, find_mapping
    outputs = tmp.parent / "properties"
    for rel, variant in stage_map.items():
        header = tmp / rel
        part = variant["parts"].get(".uexp", {})
        # Never feed a partial package with a known unreadable sidecar to a property reader.
        if header.is_file() and part and part.get("status") != "read":
            header.unlink()
    schema = find_mapping(mapping, BASE)
    if schema:
        if schema.stat().st_size <= MAX_PART:
            raw_map = schema.read_bytes()
            report["mapping"] = {"filename": schema.name, "sha256": blob(report, raw_map),
                                 "build_match": "not_verified"}
    package_paths = {rel: normalize_asset_path(next(iter(v["parts"].values()))["path"])
                     for rel, v in stage_map.items()}
    def decoded_progress(index, count, name):
        if index == count or index % 50 == 0:
            progress(f"Ресурсы: {index}/{count}")
    result = decode_packages(tmp, outputs, schema, max_assets=None,
                             package_paths=package_paths, progress=decoded_progress)
    report["decoder"] = {k: result[k] for k in ("status", "decoder", "counts", "notes") if k in result}
    for record in result.get("assets", []):
        rel = str(record["asset"]).replace("\\", "/")
        variant = stage_map.get(rel)
        if variant is None:
            continue
        detail = {k: v for k, v in record.items() if k not in {"asset", "json"}}
        variant["decode"] = detail
        target = outputs / str(record.get("json", "")).replace("\\", "/")
        if target.is_file():
            try:
                decoded = load_properties(target.read_bytes())
                detail["evidence"] = evidence(Path(rel).stem, decoded)
            except (ValueError, OSError, RecursionError) as exc:
                detail["evidence_error"] = type(exc).__name__


def read_exports(folders, report):
    seen = set()
    for folder in folders:
        for dirpath, dirs, files in os.walk(folder, followlinks=False):
            dirs[:] = [d for d in dirs if not (Path(dirpath) / d).is_symlink()]
            for filename in files:
                if not filename.lower().endswith(".json"):
                    continue
                path = Path(dirpath) / filename
                relative = path.relative_to(folder).as_posix()
                kind = target_kind(relative)
                if not kind or path.is_symlink():
                    continue
                try:
                    if path.stat().st_size > MAX_PART:
                        report["export_issues"].append({"file": relative, "reason": "size_limit"})
                        continue
                    data = path.read_bytes()
                    doc = load_properties(data)
                    digest = hashlib.sha256(data).hexdigest()
                    if (relative.casefold(), digest) in seen:
                        continue
                    seen.add((relative.casefold(), digest))
                    record = {"file": relative, "kind": kind, "sha256": blob(report, data),
                              "evidence": evidence(relative, doc)}
                    report["existing_exports"].append(record)
                except (OSError, ValueError, RecursionError) as exc:
                    report["export_issues"].append({"file": relative, "reason": type(exc).__name__})


def summarize(report):
    packages = report["packages"]
    variants = [v for p in packages.values() for v in p["variants"]]
    table = packages.get(TABLE, {})
    field_counts = Counter()
    for variant in variants:
        for name in ("ads_fields", "modifiers", "items", "bundles"):
            field_counts[name] += len(variant.get("decode", {}).get("evidence", {}).get(name, []))
    external_rows = sum(len(exp["evidence"].get("items", [])) for exp in report["existing_exports"]
                        if Path(exp["file"]).name.lower().split(".")[0] == "dt_weaponitems")
    read_any = any(p.get("status") == "read" for v in variants for p in v["parts"].values())
    status = "raw_collected" if read_any else ("exports_only" if report["existing_exports"] else "no_readable_targets")
    return {
        "collection_status": status,
        "archives": len(report["archives"]),
        "index_statuses": dict(Counter(a["index_status"] for a in report["archives"])),
        "candidate_packages": len(packages),
        "packages_with_raw_headers": sum(any(v["parts"].get(".uasset", {}).get("status") == "read"
                                             for v in p["variants"]) for p in packages.values()),
        "variants_with_header_and_sidecar": sum(all(v["parts"].get(ext, {}).get("status") == "read"
                                                   for ext in (".uasset", ".uexp")) for v in variants),
        "parts_by_status": dict(Counter(p["status"] for v in variants for p in v["parts"].values())),
        "packages_only_in_manifest": sum(p["in_manifest"] and not p["variants"] for p in packages.values()),
        "weapon_table": {"in_manifest": table.get("in_manifest", False),
                         "archive_copies": len(table.get("variants", [])),
                         "existing_export_rows": external_rows,
                         "raw_header_read": any(v["parts"].get(".uasset", {}).get("status") == "read"
                                                for v in table.get("variants", [])),
                         "decoded_rows_found": any(v.get("decode", {}).get("evidence", {}).get("items")
                                                   for v in table.get("variants", []))},
        "decoded_game_records": dict(field_counts),
        "existing_exports": len(report["existing_exports"]),
        "ranking": "not_computed",
    }


def collect(root, args):
    report = {"format": "bodycam-ads-evidence/1", "utc": datetime.now(timezone.utc).isoformat(),
              "steam_buildid": build_id(root), "manifest": {},
              "archives": [], "packages": {}, "existing_exports": [], "export_issues": [],
              "blobs": {}, "errors": [],
              "notes": ["Каждый sha256 в parts указывает на исходные байты в blobs после base64 и zlib.",
                        "Манифест перечисляет имена. Дубликаты из разных архивов оставлены раздельно.",
                        "Существующие JSON-экспорты хранятся отдельно: их сборка не подтверждена.",
                        "ADS-параметры игры и измеренное время в миллисекундах — разные величины."]}
    try:
        report["manifest"] = read_manifest(root, report)
    except OSError as exc:
        report["manifest"] = {"status": "io_error", "error": type(exc).__name__}
    with tempfile.TemporaryDirectory(prefix="bc-ads-") as scratch:
        stage = Path(scratch) / "raw"
        stage.mkdir()
        staged = {}
        try:
            scan_archives(root, report, stage, staged)
        except (ImportError, PakError, OSError, ValueError) as exc:
            report["errors"].append({"stage": "read_archives", "reason": getattr(exc, "code", type(exc).__name__)})
        if staged:
            progress("Читаю свойства найденных ресурсов…")
            try:
                decode_local(stage, staged, report, args.usmap)
            except (ImportError, OSError, RuntimeError, ValueError) as exc:
                report["errors"].append({"stage": "decode", "reason": type(exc).__name__})
    read_exports(export_roots(args.exports), report)
    summary = summarize(report)
    blobs = report.pop("blobs")
    return {"format": report.pop("format"), "summary": summary, **report, "blobs": blobs}


def main():
    for stream in (sys.stdout, sys.stderr):
        if not stream.isatty():
            stream.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", nargs="?", help="Папка установки Bodycam")
    parser.add_argument("--game", help="Папка установки Bodycam (альтернатива позиционному пути)")
    parser.add_argument("--output", type=Path, default=BASE / "bodycam_ads_report.json")
    parser.add_argument("--usmap", type=Path, help="Локальная схема свойств именно этой сборки, если она есть")
    parser.add_argument("--exports", action="append", default=[], help="Папка уже экспортированных JSON FModel")
    args = parser.parse_args()
    choice = args.game or args.folder
    interactive = choice is None
    if interactive:
        print("Вставь путь к папке Bodycam из Проводника и нажми Enter.\n"
              r"Например: D:\Steam\steamapps\common\Bodycam", flush=True)
        try:
            choice = input("> ").strip()
        except EOFError:
            parser.error("Укажи путь к игре первым аргументом.")
        if not choice:
            parser.error("Путь к игре не указан.")
    root = game_root(choice)
    while root is None and interactive:
        print("Папка не найдена. Укажи папку с Bodycam.exe или Bodycam\\Content\\Paks. "
              "Пустая строка завершает программу.", flush=True)
        try:
            choice = input("> ").strip()
        except EOFError:
            choice = ""
        if not choice:
            return 2
        root = game_root(choice)
    if args.output.suffix.casefold() != ".json":
        parser.error("Имя отчёта должно оканчиваться на .json.")
    if root is None:
        parser.error("В указанной папке не найдена установка Bodycam. Проверь путь к папке с Bodycam.exe.")
    if args.output.resolve().is_relative_to(root.resolve()) and args.output.resolve() != (BASE / "bodycam_ads_report.json").resolve():
        parser.error("Для параметра --output укажи файл вне папки игры.")
    report = collect(root, args)
    result = save_json(args.output.resolve(), report)
    summary = report["summary"]
    progress(f"Архивов: {summary['archives']}. Пакетов с прочитанным .uasset: {summary['packages_with_raw_headers']}.")
    table = summary["weapon_table"]
    if table["decoded_rows_found"]:
        progress("DT_WeaponItems: прочитаны строки таблицы.")
    elif table["raw_header_read"]:
        progress("DT_WeaponItems: сохранены доступные байты. Подробности в JSON.")
    elif table["in_manifest"]:
        progress("DT_WeaponItems есть в манифесте. Из доступных архивов прочитать таблицу не удалось.")
    else:
        progress("DT_WeaponItems: таблица не обнаружена в манифесте или индексах доступных архивов.")
    if table["existing_export_rows"]:
        progress(f"Строк в отдельном экспорте FModel: {table['existing_export_rows']}.")
    if summary["collection_status"] == "no_readable_targets":
        progress("Целевые файлы прочитать не удалось. Причины сохранены в JSON.")
    progress(f"Отчёт: {result} ({result.stat().st_size/1048576:.1f} МиБ)")
    return 0 if summary["collection_status"] != "no_readable_targets" else 1


if __name__ == "__main__":
    raise SystemExit(main())
