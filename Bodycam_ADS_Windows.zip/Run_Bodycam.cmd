@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0runtime\python.exe" goto :missing_python
if not exist "%~dp0collect_bodycam.py" goto :missing_collector
echo Starting the Bodycam ADS collector...
"%~dp0runtime\python.exe" "%~dp0collect_bodycam.py" %*
set "collector_exit=%errorlevel%"
goto :finish

:missing_python
echo Missing runtime\python.exe. Extract the whole ZIP to one folder.
set "collector_exit=2"
goto :finish

:missing_collector
echo Missing collect_bodycam.py. Extract the whole ZIP to one folder.
set "collector_exit=2"

:finish
if not "%collector_exit%"=="0" echo The collector exited with code %collector_exit%.
if "%~1"=="" pause
exit /b %collector_exit%
