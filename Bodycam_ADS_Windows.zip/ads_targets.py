"""Отбор пакетов для сверки игрового ADS, таблиц установки и ссылок на анимацию.

Нормализованный путь служит ключом сравнения и поиска. Файлы извлекаются по
исходному пути из проверенного индекса контейнера. Имена лишь выбирают кандидатов:
наличие, источник и значение свойства устанавливаются по содержимому экспорта.
"""
import re


# Названия наборов из книги и варианты внутренних ключей в таблицах и именах файлов.
# SG5-KF проверяется отдельно как заводская сборка семейства BC5.
SMG_ALIASES = {
    "Veaper": ("Veaper", "Kriss Vector", "Kriss_vector", "Vector"),
    "UZ-1": ("UZ-1", "UZ1", "UZI"),
    "USG-45": ("USG-45", "USG45", "UNT", "UMP45", "UMP-45"),
    "SG9-X": ("SG9-X", "SG9X", "MP9"),
    "SG5-K": ("SG5-K", "SG5K", "BC5", "MP5"),
    "SG5-KF": ("SG5-KF", "SG5KF", "BC5", "MP5"),
    "Skorpion": ("Skorpion", "Scorpion", "Scorpion-Evo-3", "Scorpion_EVO3"),
    "RaidX": ("RaidX", "RaiderX", "Raider-X"),
}

_TABLES = frozenset({
    "dt_weaponitems", "dt_weaponskins", "dt_itemclassesgameplaytags", "dt_basicbundles",
    "dt_newshopitem", "dt_shopitem", "dt_commonitems", "dt_wep", "dt_primarywep",
    "dt_secondarywep", "dt_gungameweplist", "dt_gungameweaponlist",
    "pda_item_data", "pda_item_class", "str_wep", "str_actor", "str_loadoutweapon",
    "str_loadoutinfo", "str_loadout",
})
_NAMES = frozenset({"st_ui_items", "st_ui_itemsclass"})
_SCHEMAS = frozenset({
    "dt_uistatmodifiersdefinition", "e_itemstatmodifieroperation", "f_itemstatisticdefinition",
    "da_bodycamanimationsettings", "f_characterweaponmontage", "str_animations",
    "str_animations_inout", "str_wep_animation", "f_adssettings", "f_adsblend",
    "adssettings", "adsspeed", "adsblend", "sprintadsspeed",
})
_CURVES = frozenset({
    "aimingincurve", "aimingoutcurve", "adsblendcurve", "aimincurve", "aimoutcurve",
    "curve_aim_in", "curve_aim_out", "curve_adsblend", "curve_ads_blend",
})
_GAME_ANIMATION_BP = frozenset({
    "ac_bodycamanimationcomponent",
})
_UE_SUFFIX = re.compile(r"\.(?:uasset|uexp|ubulk|uptnl|m\.ubulk|json)$", re.I)
_GAME_CONTENT = re.compile(r"(?:^|/)(?:Bodycam/Content|Game)/(.+)$", re.I)
_PLUGIN_CONTENT = re.compile(r"(?:^|/)Plugins/(?:[^/]+/)*?([^/]+)/Content/(.+)$", re.I)
_ANIM_PROFILE = re.compile(r"^bas_[^/]+$", re.I)

def _compact_name(value):
    return re.sub(r"[^a-z0-9]", "", value.casefold())


_MODEL_NAMES = frozenset(_compact_name(alias) for names in SMG_ALIASES.values() for alias in names)


def normalize_asset_path(path):
    """Вернуть виртуальное имя пакета без расширений. Одно имя экспорта тоже допустимо.

    Поддерживает путь из UFS, путь FModel/UnrealPak, /Game, монтирование плагина
    и SoftObjectPath вида BlueprintGeneratedClass'/Game/Folder/Name.Name_C'.
    Не возвращает суффиксы объектов или расширения UE из многочастных имён.
    """
    if not isinstance(path, str):
        return ""
    value = path.split("\t", 1)[0].strip().replace("\\", "/")
    match = re.fullmatch(r"[^'\"]*['\"]([^'\"]+)['\"]", value)
    if match:
        value = match.group(1)
    value = value.strip("'\u0022 ").lstrip("\ufeff")
    while value.startswith("../") or value.startswith("./"):
        value = value[value.index("/") + 1:]
    value = re.sub(r"/+", "/", value)
    if not value or ".." in value.split("/") or "\x00" in value:
        return ""
    # FModel can add .json after .uasset, and cooked bulk data can end in .m.ubulk.
    while True:
        shorter = _UE_SUFFIX.sub("", value)
        if shorter == value:
            break
        value = shorter
    leaf = value.rsplit("/", 1)[-1]
    if "." in leaf:
        package, obj = leaf.split(".", 1)
        obj = obj.split(":", 1)[0].casefold()
        if obj in (package.casefold(), package.casefold() + "_c") or ("/" in value and obj.isascii() and obj.isdigit()):
            value = value[:-len(leaf)] + package
    plugin = _PLUGIN_CONTENT.search(value)
    if plugin:
        return "/" + plugin.group(1) + "/" + plugin.group(2)
    game = _GAME_CONTENT.search(value)
    if game:
        return "/Game/" + game.group(1)
    # FModel may export a virtual plugin mount underneath its output directory.
    virtual = re.search(r"(?:^|/)(BodycamAnimationFramework)/(.+)$", value, re.I)
    if virtual:
        return "/" + virtual.group(1) + "/" + virtual.group(2)
    return value


def target_kind(path: str) -> str | None:
    """Назначение игрового пакета либо None. Один и тот же ответ для sidecar и FModel JSON."""
    key = normalize_asset_path(path)
    if not key:
        return None
    key = key.casefold()
    basename = key.rsplit("/", 1)[-1]
    if not basename or "." in basename:
        return None
    if basename.startswith("default__"):
        basename = basename.removeprefix("default__").removesuffix("_c")
    if _ANIM_PROFILE.fullmatch(basename):
        return "animation_profile"
    if basename in _TABLES:
        return "weapon_mapping"
    if basename in _NAMES:
        return "display_names"
    if basename in _SCHEMAS:
        return "attribute_definition"
    if basename in _CURVES:
        return "animation_curve"
    if basename in _GAME_ANIMATION_BP:
        return "animation_blueprint"
    if basename.startswith("ge_attachmentstat_"):
        return "attachment_effect"
    # Некоторые вложенные пакеты GE не носят префикс AttachmentStat.
    if basename.startswith("ge_") and "/gameplayeffects/weapons/stats/attachments/" in key:
        return "attachment_effect"
    if basename.startswith("ge_weaponstat_"):
        return "weapon_effect"
    # Только конкретные ADS-эффекты вне стандартной иерархии; исключаем похожие
    # имена текстур/материалов, видеоресурсы и локализации.
    if basename.startswith(("ge_", "ga_")) and any(
            token in _compact_name(basename) for token in ("adsspeed", "aimdownspeed", "aimdownsights", "aiminspeed")):
        return "ads_effect"
    if basename == "wep" and ("/blueprint/" in key or "/" not in key):
        return "weapon_blueprint"
    alias = _compact_name(re.sub(r"^(?:default__)?(?:bp_|wep_|wpn_|weapon_)?", "", basename)
                          .removesuffix("_c"))
    if alias in _MODEL_NAMES:
        if "blueprint" in key or basename.startswith(("bp_", "wep_", "wpn_")):
            return "weapon_blueprint"
        # Имя вида Guns/UNT/UNT.uasset часто указывает на тяжёлую модель.
        # Оставляем меш в указателе, а свойства берём из JSON, если он экспортирован.
        if "/" not in key or (path.split("\t", 1)[0].casefold().endswith(".json")
                             and "/guns/" not in key):
            return "weapon_record"
    return None
