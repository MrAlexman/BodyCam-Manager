BodycamAssetReader 1.0.0 · Windows x64 · формат пакетов Unreal Engine 5.5

Сборщик автоматически вызывает этот компонент через ads_decode.py. EXE содержит
среду .NET. Распаковка, установка SDK и настройка FModel для запуска не нужны.

Команды компонента

  BodycamAssetReader.exe --version
  BodycamAssetReader.exe --batch [путь-к-локальной-схеме.usmap]

В режиме batch компонент пишет {"ready":true} и читает из стандартного ввода
по одному JSON-объекту в строке. Ключ source указывает абсолютный путь к
извлечённому .uasset, ключ output — путь к новому временному файлу. Ответ
{"ok":true} подтверждает запись результата. Компонент читает соседний .uexp.
Адаптер Python проверяет SHA-256 EXE перед запуском, ограничивает время,
обрабатывает ошибки и создаёт читаемый JSON свойств и строк DataTable.
В публичном отчёте имена и ссылки заголовка имеют собственный раздел.

Для cooked пакетов с флагом PKG_UnversionedProperties нужна схема точной сборки
игры. Без неё доступны части исходного пакета, таблицы имён и импортов.
Модули игры, скрипты Blueprint и связанные объекты не исполняются.

Исходный код лежит в source. Для пересборки нужен Microsoft .NET SDK 8.0.428.
В каталоге source выполните команды

  dotnet restore AssetReader.csproj -r win-x64 --locked-mode
  dotnet publish AssetReader.csproj -c Release -r win-x64 --self-contained true --no-restore -o dist

В поставке SHA-256 файла BodycamAssetReader.exe равен
15b57a5e3b8c5d3ae7350f5189be64d63e86828bec50e736f1cd285b3cd129cf

Версии и происхождение зависимостей

  UAssetAPI 1.1.0, MIT
  https://www.nuget.org/packages/UAssetAPI/1.1.0
  https://github.com/atenfyr/UAssetAPI/tree/73530811a9d91ffa8959a1a4cb74cc3b9c5c6bed
  Newtonsoft.Json 13.0.3, MIT
  https://www.nuget.org/packages/Newtonsoft.Json/13.0.3
  ZstdSharp.Port 0.8.1, MIT, использует алгоритм zstd (BSD)
  https://www.nuget.org/packages/ZstdSharp.Port/0.8.1
  Microsoft .NET runtime 8.0.34, MIT и сторонние компоненты
  https://github.com/dotnet/runtime
  https://builds.dotnet.microsoft.com/dotnet/release-metadata/8.0/releases.json

Условия распространения и уведомления входят в каталог licenses.
