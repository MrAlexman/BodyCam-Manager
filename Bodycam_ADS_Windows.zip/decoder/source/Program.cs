using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UAssetAPI;
using UAssetAPI.ExportTypes;
using UAssetAPI.UnrealTypes;
using UAssetAPI.Unversioned;

// Read only loose, already extracted UE 5.5 packages. Never load preload
// dependencies from arbitrary paths in the asset, or evaluate Blueprint bytecode.
internal static class Program
{
    private const EngineVersion Version = EngineVersion.VER_UE5_5;
    private const CustomSerializationFlags Flags = CustomSerializationFlags.SkipParsingBytecode |
                                                    CustomSerializationFlags.SkipPreloadDependencyLoading;
    private static string ShortMessage(Exception ex) => ex.GetType().Name + ": " + ex.Message.Split('\n')[0][..Math.Min(480, ex.Message.Split('\n')[0].Length)];

    private static JObject ReadPackage(string filename, Usmap? mapping)
    {
        var header = new UAsset(filename, false, Version, mapping, Flags | CustomSerializationFlags.SkipLoadingExports);
        bool missingSchema = header.HasUnversionedProperties && mapping == null;
        var asset = missingSchema ? header : new UAsset(filename, Version, mapping, Flags);
        var imports = new JArray();
        foreach (var item in asset.Imports ?? new())
            imports.Add(new JObject {["n"] = item.ObjectName.ToString(), ["o"] = item.OuterIndex.Index,
                                     ["c"] = item.ClassName.ToString()});
        var exports = new JArray();
        foreach (var item in asset.Exports ?? new())
        {
            var entry = new JObject {["n"] = item.ObjectName.ToString(), ["o"] = item.OuterIndex.Index,
                                     ["c"] = item.ClassIndex.Index, ["exportKind"] = item.GetType().Name};
            if (!missingSchema && item is NormalExport normal && normal.Data != null)
                entry["data"] = JToken.Parse(asset.SerializeJsonObject(normal.Data));
            if (!missingSchema && item is DataTableExport table && table.Table?.Data != null)
                entry["rows"] = JToken.Parse(asset.SerializeJsonObject(table.Table.Data));
            if (!missingSchema && item is StringTableExport strings && strings.Table != null)
            {
                var textRows = new JObject();
                foreach (var pair in strings.Table) textRows[pair.Key.ToString()] = pair.Value.ToString();
                entry["strings"] = textRows;
            }
            exports.Add(entry);
        }
        // Names are a structural inventory, never a source of property values or inferred assignments.
        return new JObject {["format"] = 1, ["unversioned"] = asset.HasUnversionedProperties,
            ["missingSchema"] = missingSchema, ["imports"] = imports, ["exports"] = exports,
            ["names"] = new JArray(asset.GetNameMapIndexList().Select(n => n.ToString()))};
    }

    private static int Main(string[] args)
    {
        Console.InputEncoding = new UTF8Encoding(false);
        Console.OutputEncoding = new UTF8Encoding(false);
        if (args.Length == 1 && args[0] == "--version")
        {
            Console.WriteLine("BodycamAssetReader 1 / UAssetAPI " + typeof(UAsset).Assembly.GetName().Version + " / VER_UE5_5");
            return 0;
        }
        if (args.Length is < 1 or > 2 || args[0] != "--batch") return 2;
        Usmap? mappings = null;
        try { if (args.Length == 2) mappings = new Usmap(args[1]); }
        catch (Exception e) { Console.Error.WriteLine("Mapping: " + ShortMessage(e)); return 3; }
        Console.WriteLine("{\"ready\":true}");
        string? line;
        while ((line = Console.ReadLine()) != null)
        {
            try
            {
                var request = JObject.Parse(line);
                var source = (string?)request["source"] ?? throw new ArgumentException("Missing source");
                var output = (string?)request["output"] ?? throw new ArgumentException("Missing output");
                if (!Path.IsPathFullyQualified(source) || !Path.IsPathFullyQualified(output)) throw new ArgumentException("Absolute paths required");
                if (!string.Equals(Path.GetExtension(source), ".uasset", StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("A loose .uasset is required");
                var doc = ReadPackage(source, mappings);
                using (var stream = new FileStream(output, FileMode.CreateNew, FileAccess.Write))
                using (var writer = new StreamWriter(stream, new UTF8Encoding(false)))
                using (var json = new Newtonsoft.Json.JsonTextWriter(writer)) doc.WriteTo(json);
                Console.WriteLine("{\"ok\":true}");
            }
            catch (Exception e) { Console.WriteLine(new JObject {["ok"] = false, ["error"] = ShortMessage(e)}.ToString(Formatting.None)); }
        }
        return 0;
    }
}
