"""Read individual mounted UE package entries using the bundled, pinned repak release."""
from __future__ import annotations

import hashlib
import os
import platform
from pathlib import Path
import subprocess
import sys
import time
import tempfile
import threading


# Hash of the executable inside the corresponding verified upstream v0.2.3 archive.
_PLATFORMS = {
    "Windows": ("windows-x64", "repak.exe", "oo2core_9_win64.dll",
                "fcd538e5994b9bb833622d425ae346f4e0692f02d4b0025114a559f9b6286022"),
    "Linux": ("linux-x64", "repak", "liboo2corelinux64.so.9",
              "fce30661c951ce56fd2507a44a1e03637e3ea06a1b7cc8035bd62c0b37dd9457"),
}


class PakError(Exception):
    """Public messages omit native diagnostics and local path names."""
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


class PakReader:
    """List mounted paths and read a single entry from the caller-selected PAK.

    Standard Unreal mount "../../../Project/Content/" appears as "Project/Content/".
    Nonstandard mounts retain their prefixes. Path spelling and case are preserved.
    Each get explicitly names its archive, so a high-priority miss cannot silently
    fall back to an older archive here. All extracted bytes stay in memory.
    """
    def __init__(self, tool_dir: Path | None = None):
        self.tool_dir = Path(tool_dir) if tool_dir is not None else Path(__file__).resolve().parent / "vendor" / "repak"
        self._runtime = None
        self._exe = None
        self._lock = threading.Lock()
        self._cache = {}
        self._oodle = None

    def close(self):
        with self._lock:
            self._cache.clear()
            self._oodle = None
            if self._runtime is not None:
                # Windows can release an executed image or its directory shortly
                # after wait(). Cleanup errors should not discard an already-read index.
                runtime = self._runtime
                for delay in (0, 0.05, 0.15, 0.3, 0.5):
                    if delay:
                        time.sleep(delay)
                    try:
                        runtime.cleanup()
                        break
                    except FileNotFoundError:
                        break
                    except PermissionError:
                        if not Path(runtime.name).exists():
                            break
                else:
                    if Path(runtime.name).exists():
                        print("Не удалось удалить временную папку repak после завершения чтения.", file=sys.stderr)
            self._runtime = self._exe = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def _binary(self):
        with self._lock:
            if self._exe is not None:
                return self._exe
            spec = _PLATFORMS.get(platform.system())
            if not spec or platform.machine().casefold() not in ("amd64", "x86_64"):
                raise PakError("tool", "Для этой платформы нет комплектного repak 0.2.3.")
            directory, name, codec_name, expected = spec
            runtime = None
            try:
                binary = (self.tool_dir / directory / name).read_bytes()
                if hashlib.sha256(binary).hexdigest() != expected:
                    raise PakError("tool", "Контрольная сумма комплектного repak не совпадает.")
                runtime = tempfile.TemporaryDirectory(prefix="bodycam-repak-")
                work = Path(runtime.name)
                # Upstream fetch_oodle() uses current_exe().with_file_name(codec_name).
                # An existing directory satisfies exists() and cannot be loaded as a
                # dynamic library. The private directory contains no third-party DLLs.
                (work / codec_name).mkdir()
                target = work / name
                target.write_bytes(binary)
                target.chmod(0o700)
            except OSError:
                if runtime is not None:
                    runtime.cleanup()
                raise PakError("tool", "Комплектный repak или временная рабочая папка недоступны.") from None
            self._runtime, self._exe = runtime, target
            return target

    @staticmethod
    def _identity(pak):
        try:
            stat = pak.stat()
        except OSError:
            raise PakError("unreadable", "Файл PAK недоступен для чтения.") from None
        return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns

    def _run(self, args, limit):
        exe = self._binary()
        try:
            with tempfile.TemporaryFile() as errors:
                flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                # A Windows console host can retain a child working-directory handle
                # after the child exits. Keep the CWD in the stable distribution folder;
                # repak itself resolves its codec path from the private executable path.
                with subprocess.Popen([str(exe), *args], cwd=self.tool_dir.resolve(), stdin=subprocess.DEVNULL,
                                      stdout=subprocess.PIPE, stderr=errors, creationflags=flags) as child:
                    timed_out = threading.Event()
                    def stop():
                        timed_out.set()
                        child.kill()
                    timer = threading.Timer(120, stop)
                    timer.daemon = True
                    timer.start()
                    try:
                        data = child.stdout.read(limit + 1)
                        if len(data) > limit:
                            child.kill()
                            raise PakError("size", "Запись превышает допустимый размер чтения.")
                        code = child.wait()
                    finally:
                        timer.cancel()
                        timer.join()
                        if child.poll() is None:
                            child.kill()
                    if timed_out.is_set():
                        raise PakError("timeout", "Истекло время чтения PAK.")
                    if code == 0:
                        return data
                errors.seek(0)
                detail = errors.read(16384).decode("utf-8", errors="replace").casefold()
        except OSError:
            raise PakError("tool", "Не удалось запустить комплектный repak или прочитать его ответ.") from None
        if "encrypted but no key" in detail or "encrypted, but no key" in detail:
            raise PakError("encrypted", "Индекс или запись PAK зашифрованы.")
        if "oodle" in detail or "oo2core" in detail or "compression method" in detail:
            raise PakError("codec", "Для этой записи нужен неподдерживаемый кодек PAK.")
        raise PakError("unreadable", "Не удалось прочитать индекс или запись PAK.")

    def _index(self, pak):
        identity = self._identity(pak)
        cached = self._cache.get(pak)
        if cached is not None and cached[0] == identity:
            return cached[1]
        # Empty strip-prefix makes repak join each index entry to its actual mount point.
        raw = self._run(["list", "--strip-prefix=", "--", str(pak)], 128 * 1024 * 1024)
        try:
            paths = raw.decode("utf-8").split("\n")
        except UnicodeDecodeError:
            raise PakError("unreadable", "Индекс PAK содержит нечитаемое имя записи.") from None
        mapping = {}
        for path in paths:
            native = path.removesuffix("\r")
            if not native:
                continue
            mounted = native.replace("\\", "/").removeprefix("../../../")
            if not mounted or mounted in mapping or "\x00" in native:
                raise PakError("unreadable", "Неоднозначное или пустое имя записи в индексе PAK.")
            mapping[mounted] = native
        if self._identity(pak) != identity:
            raise PakError("changed", "Файл PAK изменился во время чтения индекса.")
        self._cache[pak] = identity, mapping
        return mapping

    def list(self, pak: Path) -> tuple[str, ...]:
        return tuple(self._index(Path(pak).absolute()))

    def get(self, pak: Path, mounted_path: str, max_bytes: int = 32 * 1024 * 1024) -> bytes:
        if not isinstance(max_bytes, int) or isinstance(max_bytes, bool) or max_bytes < 0:
            raise ValueError("max_bytes должен быть неотрицательным целым числом.")
        path = Path(pak).absolute()
        mapping = self._index(path)
        native = mapping.get(mounted_path)
        if native is None:
            raise PakError("missing", "В выбранном PAK нет этой записи.")
        identity = self._cache[path][0]
        try:
            data = self._run(["get", "--strip-prefix=", "--", str(path), native], max_bytes)
        except PakError as error:
            if error.code != "codec":
                raise
            # The local open-source decoder is separate from repak's download-enabled loader.
            try:
                if self._oodle is None:
                    from ads_oodle import OodlePakCache
                    self._oodle = OodlePakCache()
                data = self._oodle.get(path, mounted_path, max_bytes=max_bytes)
            except (ImportError, OSError, ValueError, RuntimeError) as cause:
                status = getattr(cause, "status", "codec")
                if status == "encrypted":
                    raise PakError("encrypted", "Индекс или запись PAK зашифрованы.") from None
                if status == "size":
                    raise PakError("size", "Запись превышает допустимый размер чтения.") from None
                if status in ("integrity", "format"):
                    raise PakError("unreadable", "Не удалось прочитать сжатую запись PAK.") from None
                if status == "missing":
                    raise PakError("missing", "В выбранном PAK нет этой записи.") from None
                raise PakError("codec", "Локальный декодер не смог прочитать эту запись PAK.") from None
            if len(data) > max_bytes:
                raise PakError("size", "Запись превышает допустимый размер чтения.")
        if self._identity(path) != identity:
            raise PakError("changed", "Файл PAK изменился во время чтения записи.")
        return data
