"""Read loose UE 5.5 packages with a bundled, pinned UAssetAPI reader.

Decoded values come only from serialized export properties or table rows. Name
and import tables are recorded separately, including when a schema is missing.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import platform
import queue
import re
import struct
import subprocess
import tempfile
import threading


_ROOT = Path(__file__).resolve().parent
_BINARIES = {
    "Windows": ("decoder/BodycamAssetReader.exe", "15b57a5e3b8c5d3ae7350f5189be64d63e86828bec50e736f1cd285b3cd129cf"),
    "Linux": ("test_decoder/BodycamAssetReader", "5cf60e363d0af45568681c121302083bbf0e0608f5fb09b7c3bb11626a6d8434"),
}
_MAP_DECODERS = {
    "Windows": ("runtime/ooz.pyd", "8b5bbb769133d3e5b8014d89ccdeb0271ab2671f46e2212af38d5be28f05bac9"),
    "Linux": ("ooz_build/ooz.abi3.so", "f8c0c470285467cacc11091c6064cadd796883f5762aa755cf281cafb1e0f13f"),
}
_PROP_META = {"$type", "Name", "ArrayIndex", "PropertyGuid", "IsZero", "PropertyTagFlags", "PropertyTypeName",
              "PropertyTagExtensions", "SerializationControl", "Operation", "StructGUID", "SerializeNone",
              "ArrayType", "ArrayProperty", "StructType", "InnerType", "DummyStruct", "EnumType", "Type"}
_REF_TYPES = {"ObjectPropertyData", "ClassPropertyData", "InterfacePropertyData", "WeakObjectPropertyData"}
_LIMIT_MAP = 256 * 1024 * 1024
_LIMIT_JSON = 128 * 1024 * 1024


def _local_map(path):
    try:
        from ads_paths import _path_local
        p = _path_local(path)
        if p is not None and p.suffix.lower() == ".usmap" and p.is_file() and 3 < p.stat().st_size < _LIMIT_MAP:
            return p.resolve()
    except (TypeError, OSError, ValueError):
        pass
    return None


def find_mapping(explicit=None, launcher_dir=None):
    """Resolve only an explicit or Bodycam-specific local mapping; never fetch a URL."""
    if explicit is not None:
        return _local_map(explicit)
    bundled = _local_map(Path(launcher_dir or _ROOT) / "Bodycam.usmap")
    if bundled:
        return bundled
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    from ads_paths import _path_local
    settings = _path_local(Path(appdata) / "FModel" / "AppSettings.json")
    try:
        if settings is None or settings.stat().st_size > 8 * 1024 * 1024:
            return None
        conf = json.loads(settings.read_text(encoding="utf-8-sig"))
        dirs = list((conf.get("PerDirectory") or {}).values())
        dirs.insert(0, conf.get("CurrentDir"))
        for profile in dirs:
            if not isinstance(profile, dict):
                continue
            game = str(profile.get("GameName", "")).casefold()
            parts = re.split(r"[/\\]+", str(profile.get("GameDirectory", "")).casefold())
            if game != "bodycam" and "bodycam" not in parts:
                continue
            endpoints = profile.get("Endpoints")
            if not isinstance(endpoints, list) or len(endpoints) < 2:
                continue
            ep = endpoints[1]   # FModel's local Mapping endpoint; index 0 is unrelated.
            if not isinstance(ep, dict) or ep.get("Overwrite") is not True:
                continue
            value = ep.get("FilePath")
            if isinstance(value, str) and Path(value).is_absolute() and not value.startswith(("\\\\", "//")):
                candidate = _local_map(value)
                if candidate:
                    return candidate
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    return None


def _validated_binary(path, digest):
    with path.open("rb") as f:
        data = f.read()
    if hashlib.sha256(data).hexdigest() != digest:
        raise ValueError("Контрольная сумма комплектного компонента не совпала.")
    return data


def _prepare_map(path, temp):
    data = path.read_bytes()
    if len(data) < 12 or data[:2] != b"\xc4\x30" or data[2] > 4:
        raise ValueError("Файл не распознан как поддерживаемая схема .usmap.")
    at = 3
    if data[2] >= 1:
        flag, = struct.unpack_from("<i", data, at)
        at += 4
        if flag > 0:
            num, = struct.unpack_from("<i", data, at + 8)
            if not 0 <= num <= 65536:
                raise ValueError("Недопустимое число версий в .usmap.")
            at += 16 + num * 20
    method, packed, unpacked = struct.unpack_from("<BII", data, at)
    if not 0 < unpacked <= _LIMIT_MAP or packed > len(data) - at - 9:
        raise ValueError("Повреждённый размер блока .usmap.")
    if method == 0 and packed != unpacked:
        raise ValueError("Неверный размер несжатой схемы.")
    if method == 1:
        # Convert an Oodle-compressed schema to a temporary plain copy with the
        # same pinned open-source decoder as the archive collector. UAssetAPI
        # must never look for a proprietary library or run code from the game.
        filename, digest = _MAP_DECODERS[platform.system()]
        # Windows locks loaded .pyd files until process exit. Keep the verified
        # shipped module in place and write only the decoded mapping to temp.
        library = _ROOT / filename
        _validated_binary(library, digest)
        spec = importlib.util.spec_from_file_location("ooz", library)
        if not spec or not spec.loader:
            raise ValueError("Не удалось открыть комплектный декодер сжатия схемы.")
        codec = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(codec)
        plain = codec.decompress(data[at + 9:at + 9 + packed], unpacked)
        if len(plain) != unpacked:
            raise ValueError("Размер распакованной схемы не совпал.")
        data = data[:at] + struct.pack("<BII", 0, unpacked, unpacked) + plain
    elif method not in (0, 3):
        raise ValueError("Для этой схемы требуется несжатый или Zstandard .usmap.")
    out = temp / "schema.usmap"
    out.write_bytes(data)
    return out


def _object_ref(index, imports, exports, package):
    if type(index) is not int:
        return {"unresolved_object_index": index}
    if not index:
        return None
    parts, seen, cursor = [], set(), index
    while cursor:
        if cursor in seen or len(seen) > 64:
            return {"unresolved_object_index": index}
        seen.add(cursor)
        items, pos = (imports, -cursor - 1) if cursor < 0 else (exports, cursor - 1)
        if not 0 <= pos < len(items):
            return {"unresolved_object_index": index}
        entry = items[pos]
        name = entry.get("n")
        if not isinstance(name, str) or not name:
            return {"unresolved_object_index": index}
        parts.append(name)
        cursor = entry.get("o")
        if type(cursor) is not int:
            return {"unresolved_object_index": index}
    parts.reverse()
    if not parts[0].startswith("/"):
        if index < 0:
            return {"unresolved_object_index": index, "object_name": parts[-1]}
        parts.insert(0, package)
    # UFS object path: Package.Object:Subobject.Child
    path = parts[0]
    if len(parts) > 1:
        path += "." + parts[1]
    if len(parts) > 2:
        path += ":" + ".".join(parts[2:])
    return {"ObjectPath": path}


def _package_name(rel):
    parts = Path(rel).with_suffix("").as_posix().split("/")
    low = [p.casefold() for p in parts]
    if "content" in low:
        i = len(low) - low[::-1].index("content") - 1
        mount = "Game"
        if i and "plugins" in low[:i]:
            mount = parts[i - 1]
        elif i and low[i - 1] == "engine":
            mount = "Engine"
        return "/" + "/".join([mount] + parts[i + 1:])
    # A short filename does not establish a mounted /Game path.
    return ".".join(parts) if len(parts) == 1 else "/".join(parts)


def _property_map(records, convert):
    groups = defaultdict(list)
    for prop in records or ():
        if not isinstance(prop, dict) or "Name" not in prop:
            continue
        groups[str(prop["Name"])].append((prop.get("ArrayIndex", 0), convert(prop)))
    return {name: values[0][1] if len(values) == 1 else [v for _, v in sorted(values, key=lambda p: p[0])]
            for name, values in groups.items()}


def _normalise(document, rel, package=None):
    imports = document.get("imports", [])
    exports = document.get("exports", [])
    package = _package_name(package or rel) if not str(package or "").startswith("/") else str(package).removesuffix(".uasset")
    def ref(i):
        return _object_ref(i, imports, exports, package)

    def convert(node):
        if isinstance(node, list):
            return [convert(v) for v in node]
        if not isinstance(node, dict):
            return node
        kind = str(node.get("$type", "")).split(",")[0].rsplit(".", 1)[-1]
        if not kind.endswith("PropertyData"):
            return {k: convert(v) for k, v in node.items() if k != "$type"}
        value = node.get("Value")
        if kind in _REF_TYPES:
            return ref(value)
        if kind == "StructPropertyData" and isinstance(value, list):
            if len(value) == 1 and isinstance(value[0], dict) and value[0].get("Name") == node.get("Name"):
                return convert(value[0])
            return _property_map(value, convert)
        if kind in {"MapPropertyData", "SetPropertyData", "ArrayPropertyData"}:
            return convert(value)
        # FText and custom engine serializers can place the actual data outside Value.
        extra = {k: convert(v) for k, v in node.items() if k not in _PROP_META and k != "Value" and v is not None}
        if extra:
            if value is not None:
                extra["Value"] = convert(value)
            return extra
        return convert(value)

    names = document.get("names", [])
    imports_out = []
    for i, item in enumerate(imports):
        if item.get("c") == "Package" and isinstance(item.get("n"), str):
            imports_out.append({"index": -(i + 1), "package": item["n"]})
    # Every entry here identifies a serialized name or package import, with no
    # implication that two entries belong to a single property or active setting.
    matches = [{"index": i, "name": name} for i, name in enumerate(names)
               if isinstance(name, str) and re.search(r"ADS|AimIn|AimDownSight|AnimationData|GameplayEffect|(?:^|/)(?:GE_|BAS_|DT_)", name, re.I)]
    inventory = {"origin": "UE package header; names/imports only", "name_count": len(names),
                 "selected_name_count": len(matches), "selected_names": matches[:512],
                 "package_import_count": len(imports_out), "package_imports": imports_out[:768]}
    output = []
    opaque = []
    for idx, item in enumerate(exports, 1):
        data = item.get("data")
        if document.get("missingSchema") or not isinstance(data, list):
            opaque.append(item.get("n", str(idx)))
            continue
        props = _property_map(data, convert)
        if isinstance(item.get("rows"), list):
            props["_rows"] = _property_map(item["rows"], convert)
        if isinstance(item.get("strings"), dict):
            props["StringTable"] = {"KeysToEntries": item["strings"]}
        cls = ref(item.get("c"))
        output.append({"name": item.get("n"), "type": cls.get("ObjectPath") if isinstance(cls, dict) else None,
                       "properties": props})
    if not output:
        return None, inventory, "references_only", (
            "Нужна соответствующая этой сборке игры схема .usmap." if document.get("missingSchema")
            else "Считан заголовок; свойства экспортов остались неразобранными.")
    if opaque:
        return {"exports": output}, inventory, "partial", "Не удалось разобрать экспорты: " + ", ".join(opaque[:12])
    return {"exports": output}, inventory, "decoded", ""


class _Reader:
    def __init__(self, exe, temp, mapping):
        self.temp = temp
        env = {"TEMP": str(temp), "TMP": str(temp), "TMPDIR": str(temp),
               "DOTNET_BUNDLE_EXTRACT_BASE_DIR": str(temp / "runtime"),
               "DOTNET_EnableDiagnostics": "0", "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
               "DOTNET_GCHeapHardLimit": "20000000"}
        if os.name == "nt":
            for key in ("SystemRoot", "WINDIR"):
                if key in os.environ:
                    env[key] = os.environ[key]
            env["PATH"] = str(Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32")
        cmd = [str(exe), "--batch"] + ([str(mapping)] if mapping else [])
        self.process = subprocess.Popen(cmd, cwd=temp, env=env, shell=False, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, encoding="utf-8", text=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        self.events = queue.Queue()
        def listen():
            try:
                for line in self.process.stdout:
                    self.events.put(line)
            finally:
                self.events.put(None)
        self.listener = threading.Thread(target=listen, daemon=True)
        self.listener.start()

    def receive(self, timeout):
        try:
            line = self.events.get(timeout=timeout)
        except queue.Empty:
            raise TimeoutError("Истекло время чтения одного пакета.") from None
        if line is None:
            raise OSError("Декодер завершился без результата.")
        return json.loads(line)

    def read(self, asset, target, timeout):
        self.process.stdin.write(json.dumps({"source": str(asset), "output": str(target)}, ensure_ascii=True) + "\n")
        self.process.stdin.flush()
        response = self.receive(timeout)
        if not response.get("ok"):
            # Native diagnostics can contain local absolute paths. The exception
            # class suffices for a shareable collection report.
            raise ValueError("UAssetAPI: " + str(response.get("error", "ошибка формата")).split(":", 1)[0])
        if not target.is_file() or target.stat().st_size > _LIMIT_JSON:
            raise ValueError("Размер расшифрованных записей выше лимита чтения.")
        with target.open(encoding="utf-8") as f:
            return json.load(f)

    def close(self):
        try:
            self.process.stdin.close()
        except (OSError, ValueError):
            pass
        if self.process.poll() is None:
            self.process.kill()
        self.process.wait()
        self.listener.join(timeout=2)
        self.process.stdout.close()


def decode_packages(extracted_root, output_dir, mapping=None, *, max_assets=250, timeout=20, progress=None, package_paths=None):
    """Return per-asset status and output paths relative to the indicated roots.

    progress(done, total, relative_path) is optional. Existing output may be
    replaced only at the same relative .json path under the output directory.
    """
    root = Path(extracted_root).resolve()
    dest = Path(output_dir).resolve()
    if not root.is_dir() or dest == root or dest in root.parents:
        raise ValueError("Нужны отдельные каталоги исходных пакетов и результата.")
    if max_assets is not None and (type(max_assets) is not int or max_assets < 0):
        raise ValueError("max_assets должен быть целым ≥ 0 или None.")
    if not 0 < timeout <= 600:
        raise ValueError("Таймаут должен быть больше нуля и не выше 600 секунд.")
    files = sorted((p for p in root.rglob("*") if p.is_file() and p.suffix.lower() == ".uasset"),
                   key=lambda p: p.as_posix().casefold())
    found = find_mapping(mapping)
    report = {"status": "ok", "decoder": "BodycamAssetReader 1 / UAssetAPI 1.1.0 / UE 5.5",
              "mapping": None, "counts": {}, "assets": [], "notes": []}
    if mapping is not None and found is None:
        report["notes"].append("Указанная схема .usmap недоступна.")
    dest.mkdir(parents=True, exist_ok=True)
    reader = None
    with tempfile.TemporaryDirectory(prefix="bodycam-reader-") as td:
        temp = Path(td)
        binary = None
        schema = None
        try:
            sysname = platform.system()
            if sysname not in _BINARIES or platform.machine().casefold() not in {"amd64", "x86_64"}:
                raise ValueError("Нет комплектного декодера для этой платформы.")
            filename, checksum = _BINARIES[sysname]
            exe = temp / Path(filename).name
            exe.write_bytes(_validated_binary(_ROOT / filename, checksum))
            exe.chmod(0o700)
            binary = exe
        except (OSError, ValueError) as err:
            report["notes"].append(str(err) if isinstance(err, ValueError) else "Комплектный декодер не найден.")
        if found:
            try:
                schema = _prepare_map(found, temp)
                report["mapping"] = {"name": found.name, "sha256": hashlib.sha256(found.read_bytes()).hexdigest()}
            except (OSError, ValueError, ImportError, KeyError, struct.error, RuntimeError):
                report["notes"].append("Схема недоступна либо её формат/сжатие не поддерживается. Применено чтение без схемы.")
        try:
            for i, source in enumerate(files):
                rel = source.relative_to(root)
                row = {"asset": rel.as_posix()}
                report["assets"].append(row)
                intermediate = temp / f"asset-{i}.json"
                try:
                    if binary is None or (max_assets is not None and i >= max_assets):
                        row.update(status="skipped", reason="Декодер недоступен." if binary is None else "Лимит количества файлов.")
                        continue
                    siblings = [source] + [p for p in (source.with_suffix(".uexp"), source.with_suffix(".ubulk")) if p.exists()]
                    if any(root not in p.resolve().parents or p.is_symlink() for p in siblings):
                        raise ValueError("Ссылка ведёт за пределы извлечённого пакета.")
                    if sum(p.stat().st_size for p in siblings if p.suffix.lower() != ".ubulk") > _LIMIT_JSON:
                        raise ValueError("Пакет превышает лимит чтения 128 МиБ.")
                    with source.open("rb") as f:
                        if f.read(4) != b"\xc1\x83\x2a\x9e":
                            raise ValueError("Нет заголовка обычного UE-пакета.")
                    if reader is None:
                        reader = _Reader(binary, temp, schema)
                        try:
                            if not reader.receive(timeout).get("ready"):
                                raise OSError("Декодер не готов.")
                        except (OSError, TimeoutError):
                            reader.close()
                            reader = None
                            if schema is None:
                                raise
                            schema = None
                            report["notes"].append("Декодер отклонил схему. Остальные данные читаются без схемы.")
                            report["mapping"] = None
                            reader = _Reader(binary, temp, None)
                            if not reader.receive(timeout).get("ready"):
                                raise OSError("Декодер не готов.")
                    doc = reader.read(source, intermediate, timeout)
                    normalized, inventory, status, why = _normalise(doc, rel, (package_paths or {}).get(rel.as_posix()))
                    row.update(status=status, reference_inventory=inventory)
                    if why:
                        row["reason"] = why
                    if normalized is not None:
                        reljson = rel.with_suffix(".json")
                        target = dest / reljson
                        if dest not in target.resolve().parents:
                            raise ValueError("Путь JSON вне каталога результата.")
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent,
                                                         prefix=".bodycam-", suffix=".tmp", delete=False) as f:
                            tmp = Path(f.name)
                            try:
                                json.dump(normalized, f, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
                                f.close()
                                os.replace(tmp, target)
                            finally:
                                f.close()
                                tmp.unlink(missing_ok=True)
                        row["json"] = reljson.as_posix()
                except (OSError, TimeoutError, ValueError, RecursionError, RuntimeError) as err:
                    row.update(status="error", reason=str(err) if isinstance(err, (ValueError, TimeoutError))
                               else "Ошибка чтения файла или процесса декодера.")
                    if isinstance(err, (OSError, TimeoutError)) and reader is not None:
                        reader.close()
                        reader = None
                finally:
                    intermediate.unlink(missing_ok=True)
                    if progress is not None:
                        progress(i + 1, len(files), row["asset"])
        finally:
            if reader is not None:
                reader.close()
    report["counts"] = dict(Counter(a["status"] for a in report["assets"]))
    if report["notes"] or any(a["status"] != "decoded" for a in report["assets"]):
        report["status"] = "partial"
    return report
