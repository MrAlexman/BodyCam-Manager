"""Read selected, unencrypted legacy PAK v10/v11 entries using a local Oodle decoder.

Layout reference: trumank/repak 355b5f62, repak/src/{pak,entry,footer}.rs.
Paths are index keys. They never become output file paths.
"""
import hashlib
import os
import struct
import zlib
from pathlib import Path


class OodlePakError(ValueError):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def _invalid(message):
    return OodlePakError("format", message)


class _Reader:
    def __init__(self, data, pos=0):
        self.data = memoryview(data)
        self.pos = pos

    def take(self, size):
        end = self.pos + size
        if size < 0 or self.pos < 0 or end > len(self.data):
            raise _invalid("Оборванная таблица PAK.")
        view = self.data[self.pos:end]
        self.pos = end
        return view

    def num(self, fmt):
        return struct.unpack("<" + fmt, self.take(struct.calcsize("<" + fmt)))[0]

    def text(self):
        count = self.num("i")
        if abs(count) > 65536:
            raise _invalid("Некорректная длина имени в индексе PAK.")
        if count == 0:
            return ""
        wide = count < 0
        raw = bytes(self.take(-2 * count if wide else count))
        end = b"\0\0" if wide else b"\0"
        if not raw.endswith(end):
            raise _invalid("Некорректная строка индекса PAK.")
        try:
            result = raw[:-len(end)].decode("utf-16-le" if wide else "utf-8")
        except UnicodeDecodeError:
            raise _invalid("Некорректная кодировка строки PAK.") from None
        if "\0" in result:
            raise _invalid("Нулевой символ в имени записи.")
        return result


def _read_at(stream, offset, size, limit):
    if offset < 0 or size < 0 or offset + size > limit:
        raise _invalid("Диапазон записи выходит за пределы PAK.")
    stream.seek(offset)
    data = stream.read(size)
    if len(data) != size:
        raise _invalid("Файл PAK обрезан.")
    return data


def _index_data(stream, offset, size, digest, end):
    if size > 128 * 1024 * 1024:
        raise OodlePakError("size", "Индекс PAK превышает 128 МиБ.")
    data = _read_at(stream, offset, size, end)
    if hashlib.sha1(data).digest() != digest:
        raise OodlePakError("integrity", "Не совпал SHA-1 индекса PAK.")
    return data


def _section(r):
    has_section = r.num("I")
    if has_section not in (0, 1):
        raise _invalid("Некорректный флаг секции PAK.")
    return (r.num("Q"), r.num("Q"), bytes(r.take(20))) if has_section else None


def _full_header(r):
    offset, packed, raw, method = struct.unpack("<QQQI", r.take(28))
    digest = bytes(r.take(20))
    count = r.num("I") if method else 0
    if count > 65535:
        raise _invalid("Слишком много блоков в записи PAK.")
    blocks = tuple(struct.iter_unpack("<QQ", r.take(count * 16)))
    flags, block_size = struct.unpack("<BI", r.take(5))
    return offset, packed, raw, method, digest, blocks, flags, block_size


def _compact(data, offset):
    r = _Reader(data, offset)
    bits = r.num("I")
    count = bits >> 6 & 0xffff
    method = bits >> 23 & 0x3f
    block_size_field = bits & 63
    if block_size_field == 63:
        r.num("I")
    def number(bit):
        return r.num("I" if bits & 1 << bit else "Q")
    start = number(31)
    raw = number(30)
    packed = number(29) if method else raw
    encrypted = bool(bits & 1 << 22)
    if count > 1 or count == 1 and encrypted:
        r.take(count * 4)
    return start, packed, raw, method, encrypted


def _parse_index(stream, size):
    end = size - 221
    footer = _read_at(stream, end, 221, size)
    encrypted, magic, version, pos, size = struct.unpack_from("<BIIQQ", footer, 16)
    if magic != 0x5a6f12e1 or version not in (10, 11):
        raise _invalid("Поддерживаются стандартные PAK версий 10 и 11.")
    if encrypted:
        raise OodlePakError("encrypted", "Индекс PAK зашифрован.")
    methods = [footer[i:i + 32].split(b"\0", 1)[0].lower() for i in range(61, 221, 32)]
    r = _Reader(_index_data(stream, pos, size, footer[41:61], end))
    mount = r.text().replace("\\", "/")
    entries = r.num("I")
    if entries > 2_000_000:
        raise OodlePakError("size", "Слишком большой каталог PAK.")
    r.num("Q")  # path hash seed
    _section(r)  # pathname hash map is unnecessary when the full directory map exists
    directory = _section(r)
    if directory is None:
        raise _invalid("Полный каталог имён отсутствует в PAK.")
    directory_data = _Reader(_index_data(stream, *directory, end))
    encoded = r.take(r.num("I"))
    explicit_count = r.num("I")
    if explicit_count > entries:
        raise _invalid("Ошибочная таблица абсолютных заголовков PAK.")
    explicit = []
    for _ in range(explicit_count):
        start, packed, raw, method, _, _, flags, _ = _full_header(r)
        explicit.append((start, packed, raw, method, bool(flags & 1)))
    files = {}
    dirs = directory_data.num("I")
    if dirs > 2_000_000:
        raise OodlePakError("size", "Слишком много каталогов PAK.")
    for _ in range(dirs):
        directory_name = directory_data.text().replace("\\", "/").removeprefix("/")
        file_count = directory_data.num("I")
        if file_count > 2_000_000:
            raise OodlePakError("size", "Слишком много записей в каталоге PAK.")
        for _ in range(file_count):
            name = directory_data.text().replace("\\", "/")
            location = directory_data.num("i")
            if location == -0x80000000:
                continue  # UE directory pruning sentinel
            key = (mount.rstrip("/") + "/" if mount else "") + directory_name + name
            key = key.removeprefix("../../../")
            if location >= len(encoded) or location < -len(explicit) or key in files:
                raise _invalid("Некорректный адрес или дубликат пути в каталоге PAK.")
            if len(files) >= 2_000_000:
                raise OodlePakError("size", "Слишком много записей PAK.")
            files[key] = location
    return files, encoded, explicit, methods, pos


def _inflate(method, data, expected):
    if method == b"oodle":
        try:
            import ooz
        except (ImportError, OSError):
            raise OodlePakError("codec", "Локальный декодер ooz недоступен.") from None
        try:
            result = ooz.decompress(data, expected)
        except Exception as exc:
            raise OodlePakError("codec", "Локальный декодер не распознал блок Oodle.") from exc
    elif method in (b"zlib", b"gzip"):
        try:
            inflater = zlib.decompressobj(31 if method == b"gzip" else 15)
            result = inflater.decompress(data, expected + 1)
            if not inflater.eof or inflater.unconsumed_tail or inflater.unused_data:
                raise _invalid("Некорректный блок Deflate.")
        except zlib.error as exc:
            raise _invalid("Повреждён блок Deflate.") from exc
    else:
        raise OodlePakError("codec", "Неизвестный метод сжатия PAK.")
    if len(result) != expected:
        raise OodlePakError("integrity", "Не совпала длина распакованного блока.")
    return result


def _data(stream, entry, methods, entries_end, max_bytes):
    start, packed, raw, slot, encrypted = entry
    if encrypted:
        raise OodlePakError("encrypted", "Запись PAK зашифрована.")
    if raw > max_bytes or packed > max_bytes + 65536:
        raise OodlePakError("size", "Запись превышает допустимый размер.")
    # The index offset points at an explicit FPakEntry header, not at the payload.
    prefix = _read_at(stream, start, 48, entries_end)
    _, disk_packed, disk_raw, disk_slot = struct.unpack_from("<QQQI", prefix)
    if (disk_packed, disk_raw, disk_slot) != (packed, raw, slot):
        raise _invalid("Заголовок записи не совпадает с индексом.")
    count = struct.unpack("<I", _read_at(stream, start + 48, 4, entries_end))[0] if slot else 0
    if count > 65535:
        raise _invalid("Некорректное число блоков записи.")
    header_size = 53 + (4 + 16 * count if slot else 0)
    header = _Reader(_read_at(stream, start, header_size, entries_end))
    _, _, _, _, digest, blocks, flags, step = _full_header(header)
    if flags & 1:
        raise OodlePakError("encrypted", "Запись PAK зашифрована.")
    if flags & 2:
        raise OodlePakError("missing", "Запись PAK удалена.")
    payload = _read_at(stream, start + header_size, packed, entries_end)
    # Some cooked data headers omit the hash; when supplied it covers the stored bytes.
    if any(digest) and hashlib.sha1(payload).digest() != digest:
        raise OodlePakError("integrity", "Не совпал SHA-1 упакованной записи.")
    if slot == 0:
        if raw != len(payload):
            raise _invalid("Длина несжатой записи не совпадает с заголовком.")
        return payload
    if not (1 <= slot <= len(methods)) or not count or not raw:
        raise _invalid("Неизвестный слот или количество блоков сжатия.")
    if count == 1:
        step = raw
    if not step or count != (raw + step - 1) // step:
        raise _invalid("Размеры блоков не соответствуют размеру записи.")
    result = bytearray()
    last = header_size
    for begin, end in blocks:
        if begin != last or not begin < end <= header_size + packed:
            raise _invalid("Некорректный интервал сжатого блока.")
        chunk = payload[begin - header_size:end - header_size]
        result.extend(_inflate(methods[slot - 1], chunk, min(step, raw - len(result))))
        last = end
    if last != header_size + packed or len(result) != raw:
        raise OodlePakError("integrity", "Суммарная длина блоков не совпала.")
    return bytes(result)


class OodlePakCache:
    """Keep the directory index of just the most recently opened PAK."""
    def __init__(self):
        self._key = None
        self._index = None

    def _open(self, stream, path):
        s = os.fstat(stream.fileno())
        key = (str(path), s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        if self._key != key:
            self._key = self._index = None
            index = _parse_index(stream, s.st_size)
            self._key, self._index = key, index
        return self._index

    def list(self, pak_path):
        path = Path(pak_path)
        with path.open("rb") as stream:
            return tuple(self._open(stream, path)[0])

    def get(self, pak_path, entry, max_bytes=32 * 1024 * 1024):
        if type(max_bytes) is not int or max_bytes < 0:
            raise ValueError("max_bytes должен быть неотрицательным целым числом.")
        path = Path(pak_path)
        with path.open("rb") as stream:
            files, encoded, explicit, methods, end = self._open(stream, path)
            if entry not in files:
                raise OodlePakError("missing", "Запись не найдена в PAK.")
            offset = files[entry]
            data_entry = _compact(encoded, offset) if offset >= 0 else explicit[-offset - 1]
            return _data(stream, data_entry, methods, end, max_bytes)
